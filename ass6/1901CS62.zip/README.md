SUSHANT SINHA
1901CS62
ASSIGNMENT 6

Q1:
Compile: g++ q1.c -o q1
Run: ./q1
Input:
3
0 5
1 7
3 4

Output:
4.33 9.67
P1 P2 P3

Q2:
Compile: g++ q2.c -o q2
Run: ./q2
Input:
3
2
0 5
1 7
3 4

Output:
6.67 12.00
P1 P3 P2

Q3:
Compile: g++ q3.c -o q3
Run: ./q3
Input:
7
0 3 2
2 5 6
1 4 3
4 2 5
6 9 7
5 4 4
7 10 10

Output:
7.71 13.00
P1 P3 P6 P4 P2 P5 P7

Q4:
Compile: g++ q4.c -o q4
Run: ./q4
Input:
4
0 2
1 5
4 3
5 2

Output:
5.00 8.00
P1 P2 P3 P4
